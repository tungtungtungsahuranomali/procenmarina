var Key = {
    'Number1': hcap.key.Code.NUM_1,
    'Number2': hcap.key.Code.NUM_2,
    'Number3': hcap.key.Code.NUM_3,
    'Number4': hcap.key.Code.NUM_4,
    'Number5': hcap.key.Code.NUM_5,
    'Number6': hcap.key.Code.NUM_6,
    'Number7': hcap.key.Code.NUM_7,
    'Number8': hcap.key.Code.NUM_8,
    'Number9': hcap.key.Code.NUM_9,
    'Number0': hcap.key.Code.NUM_0,
    'Up': hcap.key.Code.UP,
    'Left': hcap.key.Code.LEFT,
    'OK': hcap.key.Code.ENTER,
    'Right': hcap.key.Code.RIGHT,
    'Down': hcap.key.Code.DOWN,
    'Power': hcap.key.Code.POWER,
    'ChannelUp': hcap.key.Code.CH_UP,
    'ChannelDown': hcap.key.Code.CH_DOWN,
    'Red': hcap.key.Code.RED,
    'Green': hcap.key.Code.GREEN,
    'Yellow': hcap.key.Code.YELLOW,
    'Blue': hcap.key.Code.BLUE,
    'Rewind': hcap.key.Code.REWIND,
    'Play': hcap.key.Code.PLAY,
    'Pause': hcap.key.Code.PAUSE,
    'Forward': hcap.key.Code.FAST_FORWARD,
    'Stop': hcap.key.Code.STOP,
    'Back': hcap.key.Code.BACK,
    'Menu': hcap.key.Code.MENU,
    'Home': hcap.key.Code.PORTAL,
    'Exit': hcap.key.Code.EXIT,
    'Guide': hcap.key.Code.GUIDE,
    'TV': hcap.key.Code.TV,
    'Info': hcap.key.Code.INFO,
    'Opt': hcap.key.Code.T_OPT,
    'Text': hcap.key.Code.TEXT,
    'Power': hcap.key.Code.POWER,
    'Portal': hcap.key.Code.PORTAL,
}

function run() {
    window.setTimeout("initialize()", 2000);
}

function initialize() {
    try {
        setDebugMode();
        getHCAPversion();
        getSItoken("netflix", "ielwJ2viK+1NMFP3OAXGzAd64AipY4m9zqW22A9wcTmgquVImA3hVc8lJGaJDzYX1Yo04POrOzSjJjmRJQVbpMF+pcausEpwvY1YU2L+GAahTBZMSizlbIA0YU0ImbPcx2+MdFYCudkF7XdB2k8dP5N0mGW03FbHpPDfM8awehBfRz7PvbwqCBBM93MGPFC9o0ZpopZJq1mqLF+LhGvvZ61+TMgfrjOUGNkU965tnkXqP6FHQMonF2bCplQsYNZNDqp/wr1nq8O1Jbls+x7cuz8dE1Gxn6cgSwHFyxAbPbAKqLWVU0TGeH11MbF6Mu/5iE7U8l6P9X4Shs2t8optvw==");
        fetchPreloadedApplications();
        launchPreloadedApplication("244115188075859013")
        console.log("initialize completed!");
    }
    catch (e) {
        console.log("Initialize Error: " + e.message);
    }
}

function launchPreloadedApplication(appId) {
    hcap.preloadedApplication.launchPreloadedApplication({
        "id": appId,
        "parameters": JSON.stringify({
            "params": {
                "hotel_id": "OHAGB",
                "launcher_version": "0.2"
            }
        }),
        "onSuccess": function() {
            console.log("Launch Success!");
        },
        "onFailure": function(f) {
            console.log("Launch Failed! Reason: " + f.errorMessage);
        }
    });
}

function getSItoken(appId, tokenValue) {
    const siAppList = [
        { "id": appId }
    ];

    const tokenList = [
        { "id": appId, "token": tokenValue }
    ];

    console.log("Registering SI Application List:", siAppList);
    console.log("Registering Token List:", tokenList);

    hcap.application.RegisterSIApplicationList({
        "siAppList": siAppList,
        "tokenList": tokenList,
        "onSuccess": function(s) {
            console.log("Register Success!");
        },
        "onFailure": function(f) {
            console.log("Register Failed! Reason: " + f.errorMessage);
        }
    });

    document.addEventListener(
        "application_registration_result_received",
        function (param) {
            console.log("Event received:", param);

            if (param.tokenResult === "fail") {
                console.error(`Registration failed for ID: ${param.id}. Reason: ${param.errorMessage}`);
            } else {
                console.log(`Registration succeeded for ID: ${param.id}`);
            }
        },
        false
    );
}

function fetchPreloadedApplications() {
    hcap.preloadedApplication.getPreloadedApplicationList({
        "onSuccess": function(s) {
            console.log("onSuccess: list length = " + s.list.length);
            
            if (s.list.length > 0) {
                for (var i = 0; i < s.list.length; i++) {
                    console.log(
                        "list[" + i + "].id = " + s.list[i].id + ", " +
                        "list[" + i + "].title = " + s.list[i].title + ", " +
                        "list[" + i + "].iconFilePath = " + s.list[i].iconFilePath
                    );
                }
            } else {
                console.log("No preloaded applications found.");
            }
        },
        "onFailure": function(f) {
            console.log("onFailure: errorMessage = " + f.errorMessage);
        }
    });
}


function getHCAPversion () {
    hcap_version = "0.00"
    hcap.property.getProperty ({
        "key" : "hcap_js_extension_version",
        "onSuccess" : function(s) {
            console.log("getProperty Success, hcap_version : "+s.value);
            hcap_version = s.value.substring(0,4)
        },
        "onFailure" : function(f) {
            console.log("getProperty Failed! reason : " + f.errorMessage);
        }
    });
    if(hcap_version>="1.24")
        {
            // Use new feature
        }
        else {
            // Use old feature
        }
}

function setDebugMode() {
    hcap.system.setBrowserDebugMode({
        "debugMode": true,
        "onSuccess": function () {
            console.log("#Success to set browser debug mode");
        },
        "onFailure": function (f) {
            console.log("#Fail to set browser debug mode(errorMessage = " + f.errorMessage + ")");
        }
    });
}